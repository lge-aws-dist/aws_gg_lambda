#
# Copyright 2010-2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#

# greengrassHelloWorld.py
# Demonstrates a simple publish to a topic using Greengrass core sdk
# This lambda function will retrieve underlying platform information and send
# a hello world message along with the platform information to the topic
# 'hello/world'. The function will sleep for five seconds, then repeat.
# Since the function is long-lived it will run forever when deployed to a
# Greengrass core.  The handler will NOT be invoked in our example since
# the we are executing an infinite loop.

import logging
import platform
import sys

from threading import Timer

import greengrasssdk

# LNE set
from lne_tflite import interpreter as lt
import cv2
import numpy as np

# Setup logging to stdout
logger = logging.getLogger(__name__)
logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

# Creating a greengrass core sdk client
client = greengrasssdk.client("iot-data")

# Retrieving platform information to send from Greengrass Core
#my_platform = platform.platform()


# When deployed to a Greengrass core, this code will be executed immediately
# as a long-lived lambda function.  The code will enter the infinite while
# loop below.
# If you execute a 'test' on the Lambda Console, this test will fail by
# hitting the execution timeout of three seconds.  This is expected as
# this function never returns a result.

def resize_img(img, width, height, mode):
	fitted_img = cv2.resize(img, (width, height))
	fitted_img = cv2.cvtColor(fitted_img, cv2.COLOR_BGR2RGB)
	fitted_img = np.expand_dims(fitted_img, axis = 0)
	if mode == 1:
		fitted_img = fitted_img.astype('float32')
		fitted_img = (fitted_img -127.5) * (1.0 / 127.5)
	return fitted_img

def crop_image(img):
	(y,x,channel) = img.shape
	x_prime = y 
	img = img[0:y, int((x-x_prime)/2):int((x+x_prime)/2)]
	return img 

def greengrass_mobilenet_run():
	try:
		label = []

		interpreter = lt.Interpreter('./MobileNet_train_test_caffe.lne')
		interpreter.allocate_tensors()

		with open('./labels.txt') as f:
			l_lines = f.readlines()
			labels = [ line for line in l_lines ]

		capture = cv2.VideoCapture(0)
		ret, img = capture.read()
		img = crop_image(img)
		input_data = resize_img(img, 224, 224, 0)

		input_details = interpreter.get_input_details()
		output_details = interpreter.get_output_details()

		interpreter.set_tensor(input_details[0]['index'], input_data)
		interpreter.invoke()
		output_data = interpreter.get_tensor(output_details[0]['index'])

		lne_answer = np.argmax(output_data)

		client.publish(topic="tflite/lne", queueFullPolicy="AllOrException", \
				payload="Result: {}".format(labels[lne_answer]))

	except Exception as e:
		logger.error("Failed to publish message: " + repr(e))

	# Asynchronously schedule this function to be run again in 5 seconds
	Timer(5, greengrass_mobilenet_run).start()


# Start executing the function above
greengrass_mobilenet_run()


# This is a dummy handler and will not be invoked
# Instead the code above will be executed in an infinite loop for our example
def function_handler(event, context):
	return
